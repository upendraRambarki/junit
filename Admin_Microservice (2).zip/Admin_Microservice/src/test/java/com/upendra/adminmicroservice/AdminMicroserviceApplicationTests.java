package com.upendra.adminmicroservice;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.upendra.adminmicroservice.model.Flight;
import com.upendra.adminmicroservice.repository.FlightRepository;
import com.upendra.adminmicroservice.service.FlightService;
@RunWith(SpringRunner.class)
@SpringBootTest
class AdminMicroserviceApplicationTests {

	private MockMvc mockMvc;

	@Autowired
	private FlightService flightService;
	@MockBean
	private FlightRepository flightRepository;

	@Test
	@DisplayName("getAllFlight")
	public void getFlightsTest() {
		when(flightRepository.findAll())
				.thenReturn(Stream.of(new Flight("HC1", "Hyderabad", LocalDate.parse("2022-02-04", DateTimeFormatter.ISO_DATE), LocalTime.parse("13:13:13"), "mumbai", 
						LocalDate.parse("1945-02-02"), LocalTime.parse("13:13:13"), "2", 0, 29))
						.collect(Collectors.toList()));
		assertEquals(1, flightService.getFlights().size());
	}
	@Test
	@DisplayName("addFlights")
	public void testaddFlights() {
		Flight flight = new Flight();
		flight.setFlightNumber("Hc1");
		flight.setSource("hyd");
		flight.setDepartDate( LocalDate.parse("2022-02-04", DateTimeFormatter.ISO_DATE));
		flight.setDepartTime( LocalTime.parse("13:13:13"));
		flight.setDestination("chennai");
		flight.setArrivalDate(LocalDate.parse("1945-02-02"));
		flight.setArrivalTime(LocalTime.parse("13:13:13"));
		flight.setTravelTime("2");
		flight.setFare(0);
		flight.setSeatsRemaining(29);
		when(flightRepository.save(flight)).thenReturn(flight);
		assertEquals(flight, flightService.addFlight(flight));
	}
	@Test
	@DisplayName("findBySourceDestinationArrivalDate")
	public void testSearchFlight() {

		when(flightRepository.findBySourceDestinationArrivalDate("hyd", "chennai",LocalDate.parse("1945-02-02"))).thenReturn(Stream
				.of(new Flight("HC1", "Hyderabad", LocalDate.parse("2022-02-04", DateTimeFormatter.ISO_DATE), LocalTime.parse("13:13:13"), "mumbai", 
								LocalDate.parse("1945-02-02"), LocalTime.parse("13:13:13"), "2", 0, 29))
				.collect(Collectors.toList()));
		assertEquals(1, flightService.searchFlights("hyd", "chennai",LocalDate.parse("1945-02-02")).size());

	}
//	@Test
//	public void SearchFlighttest() {
//
//		Flight flight = new Flight
//				();
//		flight.setSource("chennai");
//		flight.setDestination("hyd");
//		flight.setArrivalDate(LocalDate.parse("1945-02-02"));
//		when(flightRepository.findBySourceDestinationArrivalDate("hyd", "chennai",LocalDate.parse("1945-02-02"))).thenReturn(
//				Stream.of(flight,(new Flight("HC1", "Hyderabad",LocalDate.parse("2022-02-04", DateTimeFormatter.ISO_DATE), 
//						LocalTime.parse("13:13:13"), "mumbai",LocalDate.parse("1945-02-02"), LocalTime.parse("13:13:13"), "2", 0, 29))
//						.collect(Collectors.toList())));
//		assertEquals(Boolean.TRUE, flightService.searchFlights("hyd", "chennai",LocalDate.parse("1945-02-02")).contains(flight));
//
//	}
	
//	new Flight("HC1", "Hyderabad", LocalDate.parse("2022-02-04", DateTimeFormatter.ISO_DATE), LocalTime.parse("13:13:13"), "mumbai", 
//			LocalDate.parse("1945-02-02"), LocalTime.parse("13:13:13"), "2", 0, 29)),
//			new Flight("HC1", "hyd", LocalDate.parse("2022-02-04", DateTimeFormatter.ISO_DATE), LocalTime.parse("13:13:13"), "chennai", 
//					LocalDate.parse("1945-02-02"), LocalTime.parse("13:13:13"), "2", 0, 29)),
//	@Autowired
//	private MockMvc mockMvc;
//
//	@Autowired
//	private ObjectMapper objectMapper;
//
//	@MockBean
//	private FlightService flightService;
//	
//
//	@Test
//	public void testgetFlights() throws Exception {
//		List<Flight> flightlist = new ArrayList<>();
//		flightlist.add(new Flight("1234", "mum", LocalDate.parse("2022-02-04", DateTimeFormatter.ISO_DATE),
//				LocalTime.parse("13:13:13"), "hyd", LocalDate.parse("1945-02-02"), LocalTime.parse("13:13:13"),
//				"12 hours", 0, 0));
//		Mockito.when(flightService.getFlights()).thenReturn(flightlist);
//		String url = "/flights/getFlights";
//		MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get(url))
//				.andExpect(MockMvcResultMatchers.status().isOk()).andReturn();
//		String actualJsonResponse = mvcResult.getResponse().getContentAsString();
//		System.out.println("from url" + actualJsonResponse);
//		String expectedjsonResponse = objectMapper.writeValueAsString(flightlist);
//		System.out.println("from list" + expectedjsonResponse);
//		assertEquals(expectedjsonResponse, actualJsonResponse);
//	}
//	 
//
//	@Test
//	public void testaddFlight() throws JsonProcessingException, Exception {
//		Flight flight = new Flight("1234", "mum", LocalDate.parse("2022-02-04", DateTimeFormatter.ISO_DATE),
//				LocalTime.parse("13:13:13"), "hyd", LocalDate.parse("1945-02-02"), LocalTime.parse("13:13:13"),
//				"12 hours", 0, 0);
//		
//		Mockito.when(flightService.addFlight(flight)).thenReturn(flight);
//		String url = "/flights/addFlights";
//		MvcResult mvcResult= mockMvc.perform(MockMvcRequestBuilders.post(url).contentType("application/json")
//				.content(objectMapper.writeValueAsString(flight))).andExpect(MockMvcResultMatchers.status().isOk())
//		.andReturn();
//		String actualJsonResponse = mvcResult.getResponse().getContentAsString();
//		System.out.println("from url" + actualJsonResponse);
//		
//		String expectedjsonResponse = objectMapper.writeValueAsString(flight);
//		System.out.println("from list" + expectedjsonResponse);
//		assertEquals(expectedjsonResponse, actualJsonResponse);
//		
//				
//	}


}
