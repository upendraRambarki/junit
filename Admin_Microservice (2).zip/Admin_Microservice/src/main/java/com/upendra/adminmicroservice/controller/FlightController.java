package com.upendra.adminmicroservice.controller;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.upendra.adminmicroservice.exceptions.FlightNotFoundException;
import com.upendra.adminmicroservice.logger.GlobalLogger;
import com.upendra.adminmicroservice.model.Flight;
import com.upendra.adminmicroservice.service.FlightService;


@RestController
@RequestMapping("/flights")
//@CrossOrigin("http://localhost:3000")
@CrossOrigin(origins = "*")
public class FlightController {	
	
	private Logger log = GlobalLogger.getLogger(FlightController.class);

	@Autowired
	FlightService flightService;
	
	//This method add the new flight
	@PostMapping("/addFlights")
	public String addFlight(@Valid @RequestBody Flight flight) {
		
		log.info("addFlight() method executed");
		
		flightService.addFlight(flight);
		
		return "Added Flight with ID:"+flight.getFlightNumber();
	}
	
	//This method finds the all Flights
	@GetMapping("/getFlights")
	public List<Flight> getFlights(){
		
		log.info("GetFlights() method executed");
		
		return flightService.getFlights();
	}
	//This method finds the Flights by flightNumber
	@GetMapping("/getFlightById/{flightNumber}")
	public ResponseEntity <Flight> getFlightById(@PathVariable(value = "flightNumber") String flightNumber)
			throws FlightNotFoundException
	{
		log.info("GetFlightId() method executed");
		
		Flight flight = flightService.getFlight(flightNumber);
		
		return ResponseEntity.ok().body(flight);
	}
	

	//This method update the details of flights
	@PutMapping("/updateFlight/{id}")
	public ResponseEntity <Flight> updateFlightById(@PathVariable(value = "id") String flightId, 
			@RequestBody Flight flight) throws FlightNotFoundException {
		
			log.info("updateFlightsBYId() method executed");
			
			Flight updatedFlight = flightService.updateFlight(flightId, flight);
			
			return ResponseEntity.ok().body(updatedFlight);
	}
	//This method delete the Flight by flightNo
	@DeleteMapping("/deleteFlights/{id}")
    public Map<String, Boolean> deleteFlight(@PathVariable(value = "id") String flightId)
    throws FlightNotFoundException
	{
		log.info("deleteFlightById() method executed");
		
        flightService.deleteFlight(flightId);
        
        Map < String, Boolean > response = new HashMap<>();
        
        response.put("deleted", Boolean.TRUE);
        
        return response;
    }	
	// This method find the flights by source, destination and arrivalDate
	@GetMapping("/{source}/{destination}/{arrivalDate}")
	public List<Flight> searchFlights(@PathVariable(value="source") String source,@PathVariable(value="destination") String destination
			,@PathVariable(value="arrivalDate") @DateTimeFormat(pattern =  "yyyy-MM-dd") LocalDate arrivalDate){
		
		log.info("getFlightBySourceDestinationArrivaldate method executed");
		
		return flightService.searchFlights(source,destination,arrivalDate);
	
	}	
}
