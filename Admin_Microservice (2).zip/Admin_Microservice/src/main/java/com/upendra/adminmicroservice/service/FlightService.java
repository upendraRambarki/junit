package com.upendra.adminmicroservice.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.upendra.adminmicroservice.exceptions.FlightAlreadyExistsException;
import com.upendra.adminmicroservice.exceptions.FlightNotFoundException;
import com.upendra.adminmicroservice.model.Flight;
import com.upendra.adminmicroservice.repository.FlightRepository;
@Service
public class FlightService {
	@Autowired
	FlightRepository flightRepository;
	
	public List<Flight> getFlights() {		
		
		return flightRepository.findAll();
		
	}

	public Flight addFlight(Flight flight) {
		
		Optional<Flight> existingFlight
		  =flightRepository.findById(flight.getFlightNumber());
		
		  if(!existingFlight.isPresent()) {
		 
			return flightRepository.save(flight);
			
			  } 
		  else { throw new
			  FlightAlreadyExistsException("Flight Already Exists for this id :: " +
			  existingFlight.get().getFlightNumber() );
			  
			  }
		
	}

	public Flight getFlight(String flightNumber)throws FlightNotFoundException{
		
		return flightRepository.findById(flightNumber)
				.orElseThrow(() -> new FlightNotFoundException("Flight not found for this id :: " + flightNumber));
	}

	public Flight updateFlight(String id, Flight f) throws FlightNotFoundException
	{
		
		Flight flight =  flightRepository.findById(id)
				.orElseThrow(() -> new FlightNotFoundException("Flight not found for this id :: " + id));
		
		flight = f;
		
		flight.setFlightNumber(id);
		
		flightRepository.save(flight);
		
		return flight;
		
	}

	public Flight deleteFlight(String id) throws FlightNotFoundException{
		
		Flight flight =  flightRepository.findById(id)
				.orElseThrow(() -> new FlightNotFoundException("Flight not found for this id :: " + id));
		
		flightRepository.delete(flight);
		
		return flight;
	}

	public List<Flight> searchFlights(String source, String destination, LocalDate arrivalDate) {
		
		return flightRepository.findBySourceDestinationArrivalDate(source,destination,arrivalDate);
		
	}

}
