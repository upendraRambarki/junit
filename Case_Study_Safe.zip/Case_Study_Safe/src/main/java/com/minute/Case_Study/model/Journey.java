package com.minute.Case_Study.model;

import java.time.LocalDate;
import java.time.LocalTime;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;
@Document(collection = "journeys")
public class Journey {
	
	
	
	@Id
//	@Generated()
	public String flightNo;
	public String airlineName;
	public String from;
	public String to;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy", locale = "pt-BR", timezone = "East")
	public LocalDate date;
	@JsonFormat(pattern="HH:mm:ss")
	public LocalTime startTime;
	public LocalTime reachTime;
	public int ticketCost;
	public int seatCount;
	
	public Customer customer;
	public Journey() {
		super();
	}
	public Journey(String flightNo, String airlineName, String from, String to, LocalDate date, LocalTime startTime,
			LocalTime reachTime, int ticketCost, int seatCount,Customer customer) {
		super();
		this.flightNo = flightNo;
		this.airlineName = airlineName;
		this.from = from;
		this.to = to;
		this.date = date;
		this.startTime = startTime;
		this.reachTime = reachTime;
		this.ticketCost = ticketCost;
		this.seatCount = seatCount;
		this.customer=customer;
	}
	public String getFlightNo() {
		return flightNo;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}
	public String getAirlineName() {
		return airlineName;
	}
	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public LocalTime getStartTime() {
		return startTime;
	}
	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}
	public LocalTime getReachTime() {
		return reachTime;
	}
	public void setReachTime(LocalTime reachTime) {
		this.reachTime = reachTime;
	}
	public int getTicketCost() {
		return ticketCost;
	}
	public void setTicketCost(int ticketCost) {
		this.ticketCost = ticketCost;
	}
	public int getSeatCount() {
		return seatCount;
	}
	public void setSeatCount(int seatCount) {
		this.seatCount = seatCount;
	}
	@Override
	public String toString() {
		return "Journey [flightNo=" + flightNo + ", airlineName=" + airlineName + ", from=" + from + ", to=" + to
				+ ", date=" + date + ", startTime=" + startTime + ", reachTime=" + reachTime + ", ticketCost="
				+ ticketCost + ", seatCount=" + seatCount + "]";
	}


}
