package com.minute.Case_Study.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "customers")
public class Customer {
	@Id
	public String adhaarNo;
	public String firstName;
	public String lastName;
	public int age;
	public int selectSeat;
	//public List<Journey> journey;
	public Customer() {
		super();
	}
	public Customer(String adhaarNo, String firstName, String lastName, int age, int selectSeat
			/*List<Journey> journey*/) {
		super();
		this.adhaarNo = adhaarNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.selectSeat = selectSeat;
		//this.journey = journey;
	}
	public String getAdhaarNo() {
		return adhaarNo;
	}
	public void setAdhaarNo(String adhaarNo) {
		this.adhaarNo = adhaarNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getSelectSeat() {
		return selectSeat;
	}
	public void setSelectSeat(int selectSeat) {
		this.selectSeat = selectSeat;
	}

	/*
	 * public List<Journey> getJourney() { return journey; } public void
	 * setJourney(List<Journey> journey) { this.journey = journey; }
	 */
	@Override
	public String toString() {
		return "Customer [adhaarNo=" + adhaarNo + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age
				+ ", selectSeat=" + selectSeat + /* ", journey=" + journey + */ "]";
	}
		
}
