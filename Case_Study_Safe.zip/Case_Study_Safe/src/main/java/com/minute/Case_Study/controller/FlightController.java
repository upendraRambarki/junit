package com.minute.Case_Study.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.minute.Case_Study.model.Journey;
import com.minute.Case_Study.service.FlightService;

@RestController
@RequestMapping("/flight")
public class FlightController {

	Logger logger = LoggerFactory.getLogger(FlightController.class);
	@Autowired
	private FlightService flightService;

	@GetMapping("/")
	public List<Journey> getFlights() {
		logger.trace("showing flights list ");
		return flightService.getFlights();
	}
	@GetMapping("/show")
	public ResponseEntity<List<Journey>> showflights()
	{
		List<Journey> list = flightService.showflights();
		return new ResponseEntity<>(list,list.size()>0 ? HttpStatus.OK:HttpStatus.NOT_FOUND);
	}
	

	@PostMapping("/")
	public Journey addFlight(@RequestBody Journey journey) {
		logger.info("filghts are added ");
		return flightService.addFlight(journey);
	}

	@PutMapping("/")
	public Journey updateFlight(@RequestBody Journey journey) {
		logger.trace("updated in flight list");
		return flightService.updatefight(journey);
	}

	@GetMapping("/{from}/{to}")
	public List<Journey> SearchFlights(@PathVariable(value = "from") String from,
			@PathVariable(value = "to") String to) {
		return flightService.SearchFlights(from, to);
	}

	/*
	 * 
	 * @PutMapping("/") public {
	 * 
	 * }
	 * 
	 * FlightDetailsCheck check = new FlightDetailsCheck();
	 * 
	 * @RequestMapping(value = "/booking", method = RequestMethod.GET)
	 * 
	 * public String showbookingPage() { return "booking"; }
	 * 
	 * @RequestMapping(value = "/booking", method = RequestMethod.POST) public
	 * String showWelcomePage(@RequestParam String from, @RequestParam String to,
	 * ModelMap model) { if (!check.searchValidation(from, to)) {
	 * model.put("soErrorMessage", "SourceAndDestination not be same"); return
	 * "booking"; } model.put("from", from); model.put("to", to); return
	 * "ticketPage"; }
	 */

}
