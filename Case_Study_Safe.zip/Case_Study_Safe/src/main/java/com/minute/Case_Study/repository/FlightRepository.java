package com.minute.Case_Study.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.minute.Case_Study.model.Journey;
@Repository
public interface FlightRepository extends MongoRepository<Journey, String> {
	@Query(value = "{'from':?0,'to':?1}")
	List<Journey> findAllFlights(String from,String to);

}
