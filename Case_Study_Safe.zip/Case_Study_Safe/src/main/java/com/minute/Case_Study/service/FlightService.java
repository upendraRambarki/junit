package com.minute.Case_Study.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.minute.Case_Study.model.Journey;
import com.minute.Case_Study.repository.FlightRepository;
@Service
public class FlightService {
	@Autowired
	private FlightRepository flightRepository;
	public List<Journey> getFlights()
	{
		return flightRepository.findAll();
	}
	
	public Journey addFlight(Journey journey)
	{
		return flightRepository.insert(journey);
	}	
	
	public Journey updatefight(Journey journey)
	{
		return flightRepository.save(journey);
	}

	public List<Journey> SearchFlights(String from,String to) {
		return flightRepository.findAllFlights(from,to);
	}

	public List<Journey> showflights() {
		// TODO Auto-generated method stub
		return flightRepository.findAll();
	}

	/*
	 * public List<Journey> SearchFlights(Search search ) { // TODO Auto-generated
	 * method stub return flightRepository.findAll(search); }
	 */

	
}
