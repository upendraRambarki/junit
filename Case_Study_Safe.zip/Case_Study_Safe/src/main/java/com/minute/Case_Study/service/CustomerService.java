package com.minute.Case_Study.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.minute.Case_Study.model.Customer;
import com.minute.Case_Study.repository.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	public CustomerRepository customerRepository;

	public List<Customer> getCustomer() {
		return customerRepository.findAll();
	}

	public Customer AddCustomer(Customer customer) {
		return customerRepository.insert(customer);
	}

	public List<Customer> SearchCustomer(String adhaarNo) {
		return customerRepository.findByAdhaarNo(adhaarNo);
	} 
}
