package com.minute.Case_Study.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.minute.Case_Study.model.Customer;
@Repository
public interface CustomerRepository extends MongoRepository<Customer, String> {
	@Query(value="{'adhaarNo':?0}")
	List<Customer> findByAdhaarNo(String adhaarNo);

}
