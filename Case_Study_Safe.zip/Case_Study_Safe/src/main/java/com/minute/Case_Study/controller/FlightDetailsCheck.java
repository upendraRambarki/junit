package com.minute.Case_Study.controller;

public class FlightDetailsCheck {
	 public boolean searchValidation(String from,String to) {
		  
		  if(from.equals(to)) return true;
		  return false;
		  
		  }

	
}
