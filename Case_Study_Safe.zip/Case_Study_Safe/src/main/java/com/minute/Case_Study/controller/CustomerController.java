package com.minute.Case_Study.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.minute.Case_Study.model.Customer;
import com.minute.Case_Study.service.CustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	public CustomerService cutomerService;
	
	@GetMapping("/getCustomers")
	public List<Customer> getCustomers()
	{
		
		return cutomerService.getCustomer();
	}
	@PostMapping("/addCustomer")
	public Customer AddCustomer(@RequestBody Customer customer)
	{
		return cutomerService.AddCustomer(customer);		
	}
	@GetMapping("/{adhaarNo}")
	public List<Customer> SearchCustomer(@PathVariable(value = "adhaarNo") String adhaarNo) {
		
		return cutomerService.SearchCustomer(adhaarNo);
				
	}
	
	
}
