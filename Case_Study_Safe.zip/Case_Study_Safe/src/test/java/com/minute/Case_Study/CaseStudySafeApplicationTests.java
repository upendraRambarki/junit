package com.minute.Case_Study;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.minute.Case_Study.model.Journey;
import com.minute.Case_Study.repository.FlightRepository;
import com.minute.Case_Study.service.FlightService;

@RunWith(SpringRunner.class)
@SpringBootTest
class CaseStudySafeApplicationTests {

	private MockMvc mockMvc;

	@Autowired
	private FlightService flightService;
	@MockBean
	private FlightRepository flightRepository;

	@Test
	public void getFlightsTest() {
		when(flightRepository.findAll())
				.thenReturn(Stream.of(new Journey("1", "air", "hyd", "chennai", null, null, null, 0, 0, null))
						.collect(Collectors.toList()));
		assertEquals(1, flightService.getFlights().size());
	}

	@Test
	public void testaddFlights() {
		Journey journey = new Journey();
		journey.setAirlineName("air india");
		journey.setFlightNo("2");
		journey.setFrom("hyd");
		journey.setTo("chennai");
		when(flightRepository.insert(journey)).thenReturn(journey);
		assertEquals(journey, flightService.addFlight(journey));
	}

	@Test
	public void testSearchFlight() {
//		when(flightRepository.findAllFlights("hyd", "chennai")).thenReturn("hyd", "chennai");
		/*
		 * Journye journey = new Journey(); journey.setFrom("hyd");
		 * journey.setTo("chennaI");
		 */
		when(flightRepository.findAllFlights("hyd", "chennai")).thenReturn(Stream
				.of(new Journey(null, null, "hyd", "chennai", null, null, null, 0, 0, null),
						new Journey(null, null, "hyd", "ban", null, null, null, 0, 0, null),
						new Journey(null, null, "hyd", "pun", null, null, null, 0, 0, null))
				.collect(Collectors.toList()));
		assertEquals(3, flightService.SearchFlights("hyd", "chennai").size());

	}

	@Test
	public void SearchFlighttest() {
//		when(flightRepository.findAllFlights("hyd", "chennai")).thenReturn("hyd", "chennai");
		/*
		 * Journye journey = new Journey(); journey.setFrom("hyd");
		 * journey.setTo("chennaI");
		 */
		Journey journey = new Journey
				();
		journey.setFrom("chennai");
		journey.setTo("hyd");
		when(flightRepository.findAllFlights("hyd", "chennai")).thenReturn(Stream
				.of(journey,new Journey(null, null, "hyd", "chennai", null, null, null, 0, 0, null),new Journey(null, null, "hyd", "ban", null, null, null, 0, 0, null),new Journey(null, null, "hyd", "pun", null, null, null, 0, 0, null)).collect(Collectors.toList()));
		assertEquals(Boolean.TRUE, flightService.SearchFlights("hyd","chennai").contains(journey));

	}

}
